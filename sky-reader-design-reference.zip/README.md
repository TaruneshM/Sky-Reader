# Sky Reader UI reference (frames from the target design video)

Target look: deep flat blue sky (#183161), large photoreal clouds that rise from the
bottom edge and drift away in a slow loop, app window is near-transparent frosted
glass so clouds are visible THROUGH the window. See ref_*.png (clouds at different
moments of the loop; ref_14s shows clouds almost gone, ref_3s shows the peak).
